---
name: New secure browser
about: If you discovered a browser that can't be fingerprinted
title: 'Secure browser: <Browser-Name-Here>'
labels: ''
assignees: ''

---

**Browser Name and website**

**Version** 

**Operating System used**

**Operating Systems supported**

**Notes**

<!--
Feel free to add it to the secure browser's list at https://github.com/gautamkrishnar/nothing-private/blob/master/Secure-Browsers.md

And open a PR
-->
